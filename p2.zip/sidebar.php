<?php 
    
    if(!isset($_SESSION['admin_name'])){
        
        echo "<script>window.open('login.php','_self')</script>";
        
    }else{

?>
   
<nav class="navbar navbar-inverse navbar-fixed-top"><!-- navbar navbar-inverse navbar-fixed-top begin -->
    <div class="navbar-header"><!-- navbar-header begin -->
        
    
        
        <a href="adminindex.php?adminpic" class="navbar-brand">Admin Panel </a>
        
    </div><!-- navbar-header finish -->
    
    <ul class="nav navbar-right top-nav"><!-- nav navbar-right top-nav begin -->
        
        <li class="dropdown"><!-- dropdown begin -->
            
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><!-- dropdown-toggle begin -->
                
                <i class="fa fa-user"></i> <?php echo $admin_name;  ?> <b class="caret"></b>
                
            </a><!-- dropdown-toggle finish -->
            
            <ul class="dropdown-menu"><!-- dropdown-menu begin -->
               
           
                
                <li><!-- li begin -->
                    <a href="adminindex.php?view_products"><!-- a href begin -->
                        
                        <i class="fa fa-fw fa-envelope"></i> Products
                        
                        <span class="badge"><?php echo $count_products; ?></span>
                        
                    </a><!-- a href finish -->
                </li><!-- li finish -->
                
                <li><!-- li begin -->
                    <a href="adminindex.php?view_customers"><!-- a href begin -->
                        
                        <i class="fa fa-fw fa-users"></i> Customers
                        
                        <span class="badge"><?php echo $count_customers; ?></span>
                        
                    </a><!-- a href finish -->
                </li><!-- li finish -->
                
               
                
                <li class="divider"></li>
                
                <li><!-- li begin -->
                    <a href="adminlogout.php"><!-- a href begin -->
                        
                        <i class="fa fa-fw fa-power-off"></i> Log Out
                        
                    </a><!-- a href finish -->
                </li><!-- li finish -->
                
            </ul><!-- dropdown-menu finish -->
            
        </li><!-- dropdown finish -->
        
    </ul><!-- nav navbar-right top-nav finish -->
    
    <div class="collapse navbar-collapse navbar-ex1-collapse"><!-- collapse navbar-collapse navbar-ex1-collapse begin -->
        <ul class="nav navbar-nav side-nav"><!-- nav navbar-nav side-nav begin -->
            
        <li><!-- li begin -->
                <a href="#" style="text-align:center" ><h3><!-- a href begin -->
                        
                       Menu
    </h3> 
                </a><!-- a href finish -->
                
            </li><!-- li finish -->
            
            <li><!-- li begin -->
                <a href="adminindex.php?manage" ><!-- a href begin -->
                        
                        Product Master
                        
                </a><!-- a href finish -->
                
            </li><!-- li finish -->

            <li><!-- li begin -->
                <a href="adminindex.php?manage_orders" ><!-- a href begin -->
                        
                        Order Master
                        
                </a><!-- a href finish -->
                
            </li><!-- li finish -->

            <li><!-- li begin -->
                <a href="adminindex.php?manage_customers" ><!-- a href begin -->
                        
                        User Master
                        
                </a><!-- a href finish -->
                
            </li><!-- li finish -->
            
            <li><!-- li begin -->
                <a href="adminindex.php?insert_slide" ><!-- a href begin -->
                        
                        Insert Slides
                        
                </a><!-- a href finish -->
                
            </li><!-- li finish -->

            <li><!-- li begin -->
                <a href="adminindex.php?view_slides" ><!-- a href begin -->
                        
                       View Slides
                        
                </a><!-- a href finish -->
                
            </li><!-- li finish -->

            

            <li><!-- li begin -->
                <a href="adminindex.php?customer_report" ><!-- a href begin -->
                        
                       Customer Report
                        
                </a><!-- a href finish -->
                
            </li><!-- li finish -->

            <li><!-- li begin -->
                <a href="adminindex.php?product_report" ><!-- a href begin -->
                        
                        Product Report
                        
                </a><!-- a href finish -->
                
            </li><!-- li finish -->

            <li class="menu-item-has-children dropdown"><!-- li begin -->
                <a href="adminindex.php?order_report" ><!-- a href begin -->
                        
                        Order Report
                        
                </a><!-- a href finish -->
                
            </li><!-- li finish -->
           
            
        </ul><!-- nav navbar-nav side-nav finish -->
    </div><!-- collapse navbar-collapse navbar-ex1-collapse finish -->
    
</nav><!-- navbar navbar-inverse navbar-fixed-top finish -->

    
<?php } ?>
