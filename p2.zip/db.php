<?php 

$con = mysqli_connect("localhost","root","","plaza_tech_company");

if(mysqli_connect_error()){
    echo "cnt conct";
}


?>